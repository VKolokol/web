from bells_framework.html.templator import render

from db.store import db


class Index:
    def __call__(self, request):
        return '200 OK', render(template_name='base/homepage.html', games=db)


class Contacts:
    def __call__(self, request):
        return '200 OK', render(template_name='contacts.html')
