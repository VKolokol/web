db = [
    {
        "name": "Need for Speed: Underground 2",
        "banner": "nfs2.jpg",
        "describe": "Need for Speed: Underground 2 is a cross-platform racing video game and the eighth installment in the Need for Speed series, the direct sequel to Need for Speed: Underground.",
        "created_at": "2021-11-29T16:43:13.520Z",
    },
    {
        "name": "Devil May Cry 4",
        "banner": "images.jpeg",
        "describe": "Devil May Cry 4 is a 2008 action-adventure game developed and published by Capcom. It was released for the PlayStation 3, Xbox 360, and Microsoft Windows platforms. It is the fourth installment in the Devil May Cry series and is written by Bingo Morihashi and directed by Hideaki Itsuno.",
        "created_at": "2021-11-29T16:43:13.520Z",
    },
    {
        "name": "Mortal Kombat 9",
        "banner": "ccc6d7323e369c6770d6f4fb17fbf27c.jpg",
        "describe": "Mortal Kombat (also known as MK9) is a fighting video game developed by NetherRealm Studios and published by Warner Bros. Interactive Entertainment. The game is the ninth main installment in the Mortal Kombat series and a soft reboot of the franchise. The game was released for the PlayStation 3 and",
        "created_at": "2021-11-29T16:43:13.520Z",
    }
]
