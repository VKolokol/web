SETTINGS = {
    'STATICFILES': '/static/',
    'STATIC': '/static/',
}
