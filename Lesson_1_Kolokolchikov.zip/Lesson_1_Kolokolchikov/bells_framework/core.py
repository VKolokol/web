from bells_framework.view import PageNotFound404
from bells_framework.utils import proxy_class
from bells_framework.settings import SETTINGS


@proxy_class
class BellsFW:

    def __init__(self, routes: dict, middlewares: list):
        self.routes = routes
        self.middlewares = middlewares
        self.request = {}

    def __call__(self, environ, response):
        path = environ['PATH_INFO']
        print(path)

        if not path.endswith('/'):
            path = f'{path}/'

        view = self.get_view(path)
        self.add_middleware(self.middlewares)

        code, body = view(self.request)
        response(code, [('Content-Type', 'text/html')])
        return [body.encode('utf-8')]

    def add_middleware(self, middlewares):
        for middleware in middlewares:
            middleware(self.request)

    def get_view(self, path):
        if route := self.routes.get(path):
            return route
        return PageNotFound404()

    @staticmethod
    def config(settings: dict):
        SETTINGS.update(settings)

