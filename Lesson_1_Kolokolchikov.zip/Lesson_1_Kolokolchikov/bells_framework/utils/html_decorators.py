from whitenoise import WhiteNoise


class ProxyWithStatic(WhiteNoise):
    def config(self, settings):
        self.application.config(settings)


def proxy_class(cls):
    # Основной фреймворк работает через класс WhiteNoise для работы со статикой

    def wrapper(*args, **kwargs):
        return ProxyWithStatic(cls(*args, **kwargs))

    return wrapper


__all__ = ['proxy_class']
