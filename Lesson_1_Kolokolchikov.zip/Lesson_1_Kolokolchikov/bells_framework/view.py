from jinja2 import Template


class PageNotFound404:
    def __call__(self, request):
        return "404 WHAT", "404 PAGE NOT FOUND"
