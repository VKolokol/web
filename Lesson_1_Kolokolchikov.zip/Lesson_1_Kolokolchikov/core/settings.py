import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


SETTINGS = {
    'STATICFILES': os.path.join(BASE_DIR, '../static'),
    'MEDIAFILES': os.path.join(BASE_DIR, '../media')
}
