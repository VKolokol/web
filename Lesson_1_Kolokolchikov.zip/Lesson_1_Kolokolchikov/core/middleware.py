from datetime import datetime


def add_datetime_to_request(request):
    request['datetime'] = datetime.now()


def add_user_to_request(request):
    request['user'] = {
        'name': 'NoName',
        'status': 'guest'
    }


middlewares = [add_user_to_request, add_datetime_to_request]
