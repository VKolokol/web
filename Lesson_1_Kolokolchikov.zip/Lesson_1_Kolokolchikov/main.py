from wsgiref.simple_server import make_server


from bells_framework import BellsFW
from core.urls import routes
from core.middleware import middlewares
from core.settings import SETTINGS


app = BellsFW(routes, middlewares)
app.config(SETTINGS)
app.add_files(SETTINGS.get('STATICFILES'))
app.add_files(SETTINGS.get('MEDIAFILES'), prefix='media')


if __name__ == "__main__":
    with make_server('', 8080, app) as http:
        print("Start server on http://localhost:8080")
        http.serve_forever()
